import { Difficulty } from "@shared/schema";
import { cn } from "@/lib/utils";

interface DifficultySelectorProps {
  currentDifficulty: Difficulty;
  onDifficultyChange: (difficulty: Difficulty) => void;
  disabled?: boolean;
}

export function DifficultySelector({
  currentDifficulty,
  onDifficultyChange,
  disabled = false,
}: DifficultySelectorProps) {
  const difficulties = [
    {
      value: "easy" as const,
      label: "Mudah",
      description: "Grid 8x8, 5 kata",
    },
    {
      value: "medium" as const,
      label: "Sedang", 
      description: "Grid 10x10, 8 kata",
    },
    {
      value: "hard" as const,
      label: "Sulit",
      description: "Grid 12x12, 12 kata",
    },
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm p-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Tingkat Kesulitan</h3>
      
      <div className="space-y-2">
        {difficulties.map((difficulty) => (
          <button
            key={difficulty.value}
            onClick={() => onDifficultyChange(difficulty.value)}
            disabled={disabled}
            className={cn(
              "w-full p-3 text-left rounded-lg border-2 transition-colors",
              currentDifficulty === difficulty.value
                ? "bg-secondary/10 border-secondary hover:bg-secondary/20"
                : "bg-gray-50 border-gray-200 hover:bg-gray-100",
              disabled && "opacity-50 cursor-not-allowed"
            )}
          >
            <div
              className={cn(
                "font-medium",
                currentDifficulty === difficulty.value ? "text-secondary" : "text-gray-700"
              )}
            >
              {difficulty.label}
            </div>
            <div className="text-xs text-gray-600">{difficulty.description}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
