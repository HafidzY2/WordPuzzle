import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Trophy } from "lucide-react";

interface GameCompleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  score: number;
  timeElapsed: string;
  wordsFound: number;
  totalWords: number;
  onNextLevel: () => void;
  onPlayAgain: () => void;
}

export function GameCompleteModal({
  isOpen,
  onClose,
  score,
  timeElapsed,
  wordsFound,
  totalWords,
  onNextLevel,
  onPlayAgain,
}: GameCompleteModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-4">
              <Trophy className="w-8 h-8 text-white" />
            </div>
            
            <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
              Selamat!
            </DialogTitle>
            <p className="text-gray-600 mb-6">Anda berhasil menyelesaikan puzzle ini</p>
          </div>
        </DialogHeader>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-xl font-bold text-primary">{score.toLocaleString()}</div>
            <div className="text-xs text-gray-500">Skor</div>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-xl font-bold text-accent">{timeElapsed}</div>
            <div className="text-xs text-gray-500">Waktu</div>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-xl font-bold text-secondary">
              {wordsFound}/{totalWords}
            </div>
            <div className="text-xs text-gray-500">Kata</div>
          </div>
        </div>
        
        <div className="space-y-3">
          <Button
            onClick={onNextLevel}
            className="w-full"
          >
            Level Selanjutnya
          </Button>
          <Button
            onClick={onPlayAgain}
            variant="outline"
            className="w-full"
          >
            Main Lagi
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
