import { Play, Pause, RotateCcw, Square } from "lucide-react";

interface GameControlsProps {
  isPlaying: boolean;
  isPaused: boolean;
  onNewGame: () => void;
  onPauseGame: () => void;
  onResetGame: () => void;
}

export function GameControls({
  isPlaying,
  isPaused,
  onNewGame,
  onPauseGame,
  onResetGame,
}: GameControlsProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4">
      <div className="space-y-3">
        <button
          onClick={onNewGame}
          className="w-full px-4 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-medium flex items-center justify-center"
        >
          <Play className="w-4 h-4 mr-2" />
          Game Baru
        </button>
        
        {isPlaying && (
          <button
            onClick={onPauseGame}
            className="w-full px-4 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium flex items-center justify-center"
          >
            {isPaused ? (
              <>
                <Play className="w-4 h-4 mr-2" />
                Lanjut
              </>
            ) : (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Jeda
              </>
            )}
          </button>
        )}
        
        <button
          onClick={onResetGame}
          className="w-full px-4 py-3 bg-destructive/10 text-destructive rounded-lg hover:bg-destructive/20 transition-colors font-medium border border-destructive/20 flex items-center justify-center"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </button>
      </div>
    </div>
  );
}
