import { GameState } from "@shared/schema";

interface GameStatsProps {
  gameState: GameState;
  timeRemaining: string;
}

export function GameStats({ gameState, timeRemaining }: GameStatsProps) {
  if (!gameState) return null;

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Score */}
        <div className="text-center">
          <div className="text-2xl font-bold text-primary">{gameState.score.toLocaleString()}</div>
          <div className="text-sm text-gray-500">Skor</div>
        </div>
        
        {/* Timer */}
        <div className="text-center">
          <div className="text-2xl font-bold text-accent">{timeRemaining}</div>
          <div className="text-sm text-gray-500">Waktu</div>
        </div>
        
        {/* Level */}
        <div className="text-center">
          <div className="text-2xl font-bold text-secondary">{gameState.level}</div>
          <div className="text-sm text-gray-500">Level</div>
        </div>
        
        {/* Words Found */}
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-700">
            <span>{gameState.foundWords.length}</span>/<span>{gameState.words.length}</span>
          </div>
          <div className="text-sm text-gray-500">Kata</div>
        </div>
      </div>
    </div>
  );
}
