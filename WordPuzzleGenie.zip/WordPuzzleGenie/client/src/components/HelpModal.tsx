import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function HelpModal({ isOpen, onClose }: HelpModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-2xl font-bold text-gray-900">
              Cara Bermain
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-3">🎯 Tujuan Permainan</h4>
            <p className="text-gray-600">
              Temukan semua kata yang tersembunyi dalam grid huruf. Kata dapat tersusun secara 
              horizontal, vertikal, atau diagonal.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-3">🖱️ Cara Memilih Kata</h4>
            <ul className="space-y-2 text-gray-600">
              <li>• Klik pada huruf pertama kata yang ingin dipilih</li>
              <li>• Seret kursor ke huruf terakhir kata tersebut</li>
              <li>• Lepaskan klik untuk mengonfirmasi pilihan</li>
              <li>• Kata yang benar akan berubah warna hijau</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-3">⭐ Sistem Penilaian</h4>
            <ul className="space-y-2 text-gray-600">
              <li>• Setiap kata yang ditemukan memberikan poin</li>
              <li>• Waktu menyelesaikan mempengaruhi bonus poin</li>
              <li>• Menggunakan petunjuk mengurangi poin</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-3">💡 Tips Bermain</h4>
            <ul className="space-y-2 text-gray-600">
              <li>• Cari kata pendek terlebih dahulu</li>
              <li>• Perhatikan huruf yang jarang muncul</li>
              <li>• Gunakan petunjuk jika benar-benar kesulitan</li>
              <li>• Berlatihlah dengan tingkat mudah dulu</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
