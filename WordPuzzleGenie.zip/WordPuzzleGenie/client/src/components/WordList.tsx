import { WordPosition } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

interface WordListProps {
  words: WordPosition[];
}

export function WordList({ words }: WordListProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Daftar Kata</h3>
      
      <div className="space-y-2">
        {words.map((wordPos, index) => (
          <div
            key={index}
            className={cn(
              "flex items-center justify-between p-2 rounded-lg",
              wordPos.found ? "bg-secondary/10" : "bg-gray-50"
            )}
          >
            <span
              className={cn(
                "font-medium",
                wordPos.found ? "text-secondary line-through" : "text-gray-700"
              )}
            >
              {wordPos.word}
            </span>
            {wordPos.found ? (
              <Check className="w-4 h-4 text-secondary" />
            ) : (
              <span className="text-xs text-gray-400">
                {wordPos.word.length} huruf
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
