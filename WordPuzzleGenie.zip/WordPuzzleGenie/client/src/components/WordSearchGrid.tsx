import { GameState, GameCell } from "@shared/schema";
import { cn } from "@/lib/utils";

interface WordSearchGridProps {
  gameState: GameState;
  onCellMouseDown: (cell: GameCell) => void;
  onCellMouseEnter: (cell: GameCell) => void;
  onCellMouseUp: () => void;
  onUseHint: () => void;
  onShuffle: () => void;
}

export function WordSearchGrid({
  gameState,
  onCellMouseDown,
  onCellMouseEnter,
  onCellMouseUp,
  onUseHint,
  onShuffle,
}: WordSearchGridProps) {
  if (!gameState) return null;

  const gridSize = gameState.grid.length;

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-gray-900 mb-2">Cari Kata Tersembunyi</h2>
        <p className="text-sm text-gray-600">Klik dan seret untuk memilih kata</p>
      </div>
      
      {/* Word Search Grid */}
      <div 
        className={cn(
          "grid gap-1 max-w-lg mx-auto mb-6 select-none",
          `grid-cols-${gridSize}`
        )}
        style={{ 
          gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))` 
        }}
      >
        {gameState.grid.map((row, rowIndex) =>
          row.map((cell, colIndex) => (
            <div
              key={`${rowIndex}-${colIndex}`}
              className={cn(
                "game-cell",
                cell.isSelected && "selected",
                cell.isFound && "found"
              )}
              onMouseDown={() => onCellMouseDown(cell)}
              onMouseEnter={() => onCellMouseEnter(cell)}
              onMouseUp={onCellMouseUp}
              onTouchStart={(e) => {
                e.preventDefault();
                onCellMouseDown(cell);
              }}
              onTouchMove={(e) => {
                e.preventDefault();
                const touch = e.touches[0];
                const element = document.elementFromPoint(touch.clientX, touch.clientY);
                const cellElement = element?.closest('[data-row]') as HTMLElement;
                if (cellElement) {
                  const row = parseInt(cellElement.dataset.row || "0");
                  const col = parseInt(cellElement.dataset.col || "0");
                  const targetCell = gameState.grid[row]?.[col];
                  if (targetCell) {
                    onCellMouseEnter(targetCell);
                  }
                }
              }}
              onTouchEnd={onCellMouseUp}
              data-row={rowIndex}
              data-col={colIndex}
            >
              {cell.letter}
            </div>
          ))
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex justify-center space-x-3">
        <button 
          onClick={onUseHint}
          className="px-6 py-2 bg-accent text-white rounded-lg hover:bg-accent/90 transition-colors font-medium"
          disabled={gameState.isComplete || !gameState.isPlaying}
        >
          <i className="fas fa-lightbulb mr-2"></i>
          Petunjuk
        </button>
        <button 
          onClick={onShuffle}
          className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
          disabled={gameState.isComplete || !gameState.isPlaying}
        >
          <i className="fas fa-random mr-2"></i>
          Acak
        </button>
      </div>
    </div>
  );
}
