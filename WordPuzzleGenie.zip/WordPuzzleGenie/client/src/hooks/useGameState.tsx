import { useState, useCallback, useEffect } from "react";
import { GameState, GameCell, WordPosition, Difficulty } from "@shared/schema";
import { generateGrid, isValidWordSelection, calculateScore, getRandomHint } from "@/lib/wordSearch";
import { useTimer } from "./useTimer";

const STORAGE_KEY = "wordPuzzleGame";

export function useGameState() {
  const [gameState, setGameState] = useState<GameState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    return null;
  });

  const [selectedCells, setSelectedCells] = useState<GameCell[]>([]);
  const [isSelecting, setIsSelecting] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  const timer = useTimer(300); // 5 minutes

  // Save game state to localStorage
  useEffect(() => {
    if (gameState) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
    }
  }, [gameState]);

  // Check for game completion
  useEffect(() => {
    if (gameState && !gameState.isComplete) {
      const allWordsFound = gameState.words.every(word => word.found);
      if (allWordsFound) {
        setGameState(prev => prev ? { ...prev, isComplete: true, isPlaying: false } : null);
        timer.pause();
      }
    }
  }, [gameState, timer]);

  // Handle timer expiration
  useEffect(() => {
    if (timer.isTimeUp && gameState?.isPlaying) {
      setGameState(prev => prev ? { ...prev, isPlaying: false } : null);
    }
  }, [timer.isTimeUp, gameState?.isPlaying]);

  const startNewGame = useCallback((difficulty: Difficulty) => {
    const { grid, words } = generateGrid(difficulty);
    
    setGameState({
      grid,
      words,
      foundWords: [],
      score: 0,
      level: 1,
      timeElapsed: 0,
      isPlaying: true,
      isPaused: false,
      isComplete: false,
      difficulty,
      hintsUsed: 0,
    });
    
    setSelectedCells([]);
    timer.reset(300);
    timer.start();
  }, [timer]);

  const pauseGame = useCallback(() => {
    if (gameState) {
      setGameState(prev => prev ? { ...prev, isPaused: !prev.isPaused } : null);
      if (gameState.isPaused) {
        timer.start();
      } else {
        timer.pause();
      }
    }
  }, [gameState, timer]);

  const resetGame = useCallback(() => {
    if (gameState) {
      startNewGame(gameState.difficulty);
    }
  }, [gameState, startNewGame]);

  const selectCell = useCallback((cell: GameCell) => {
    if (!gameState?.isPlaying || gameState.isPaused) return;

    setIsSelecting(true);
    setSelectedCells([cell]);
    
    // Update grid selection
    setGameState(prev => {
      if (!prev) return null;
      const newGrid = prev.grid.map(row =>
        row.map(c => ({
          ...c,
          isSelected: c.row === cell.row && c.col === cell.col
        }))
      );
      return { ...prev, grid: newGrid };
    });
  }, [gameState]);

  const extendSelection = useCallback((cell: GameCell) => {
    if (!isSelecting || !gameState?.isPlaying || gameState.isPaused) return;

    setSelectedCells(prev => {
      if (prev.length === 0) return [cell];
      
      const first = prev[0];
      const dx = cell.row - first.row;
      const dy = cell.col - first.col;
      
      // Check if selection forms a straight line
      if (dx === 0 || dy === 0 || Math.abs(dx) === Math.abs(dy)) {
        const stepX = dx === 0 ? 0 : dx / Math.abs(dx);
        const stepY = dy === 0 ? 0 : dy / Math.abs(dy);
        const distance = Math.max(Math.abs(dx), Math.abs(dy));
        
        const newSelection: GameCell[] = [];
        for (let i = 0; i <= distance; i++) {
          const row = first.row + stepX * i;
          const col = first.col + stepY * i;
          if (gameState.grid[row] && gameState.grid[row][col]) {
            newSelection.push(gameState.grid[row][col]);
          }
        }
        
        // Update grid selection
        setGameState(prevState => {
          if (!prevState) return null;
          const newGrid = prevState.grid.map(row =>
            row.map(c => ({
              ...c,
              isSelected: newSelection.some(selected => 
                selected.row === c.row && selected.col === c.col
              )
            }))
          );
          return { ...prevState, grid: newGrid };
        });
        
        return newSelection;
      }
      
      return prev;
    });
  }, [isSelecting, gameState]);

  const finishSelection = useCallback(() => {
    if (!gameState?.isPlaying || gameState.isPaused) return;

    const foundWord = isValidWordSelection(selectedCells, gameState.words);
    
    if (foundWord) {
      // Mark word as found
      setGameState(prev => {
        if (!prev) return null;
        
        const newWords = prev.words.map(w =>
          w.word === foundWord ? { ...w, found: true } : w
        );
        
        const timeBonus = Math.max(0, timer.timeRemaining - 240); // Bonus for time remaining
        const wordScore = calculateScore(foundWord, timeBonus, prev.hintsUsed, prev.difficulty);
        
        const newGrid = prev.grid.map(row =>
          row.map(cell => {
            const isPartOfFoundWord = selectedCells.some(selected =>
              selected.row === cell.row && selected.col === cell.col
            );
            return {
              ...cell,
              isSelected: false,
              isFound: isPartOfFoundWord ? true : cell.isFound,
              wordId: isPartOfFoundWord ? foundWord : cell.wordId,
            };
          })
        );
        
        return {
          ...prev,
          words: newWords,
          foundWords: [...prev.foundWords, foundWord],
          score: prev.score + wordScore,
          grid: newGrid,
        };
      });
      
      // Play success sound
      if (soundEnabled) {
        // Could implement sound here
      }
    } else {
      // Clear selection
      setGameState(prev => {
        if (!prev) return null;
        const newGrid = prev.grid.map(row =>
          row.map(c => ({ ...c, isSelected: false }))
        );
        return { ...prev, grid: newGrid };
      });
    }
    
    setSelectedCells([]);
    setIsSelecting(false);
  }, [gameState, selectedCells, timer.timeRemaining, soundEnabled]);

  const useHint = useCallback(() => {
    if (!gameState?.isPlaying || gameState.isPaused) return null;
    
    const hint = getRandomHint(gameState.words);
    if (hint) {
      setGameState(prev => prev ? { ...prev, hintsUsed: prev.hintsUsed + 1 } : null);
    }
    
    return hint;
  }, [gameState]);

  const toggleSound = useCallback(() => {
    setSoundEnabled(prev => !prev);
  }, []);

  return {
    gameState,
    selectedCells,
    isSelecting,
    soundEnabled,
    timer,
    startNewGame,
    pauseGame,
    resetGame,
    selectCell,
    extendSelection,
    finishSelection,
    useHint,
    toggleSound,
  };
}
