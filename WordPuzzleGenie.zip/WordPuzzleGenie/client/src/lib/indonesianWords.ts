export const INDONESIAN_WORDS = {
  easy: [
    // Animals (Hewan)
    "KUCING", "ANJING", "BURUNG", "IKAN", "SAPI", "KAMBING", "AYAM", "BEBEK",
    // Fruits (Buah)
    "APEL", "PISANG", "JERUK", "MANGGA", "MELON", "ANGGUR", "PEPAYA", "NANAS",
    // Colors (Warna)
    "MERAH", "BIRU", "HIJAU", "KUNING", "PUTIH", "HITAM", "UNGU", "PINK",
    // Family (Keluarga)
    "IBU", "AYAH", "ANAK", "KAKAK", "ADIK", "NENEK", "KAKEK", "PAMAN",
  ],
  medium: [
    // Vegetables (Sayuran)
    "TOMAT", "WORTEL", "BAYAM", "KANGKUNG", "BAWANG", "TERONG", "JAGUNG", "KENTANG",
    // Transportation (Transportasi)
    "MOBIL", "MOTOR", "SEPEDA", "KAPAL", "PESAWAT", "KERETA", "BUS", "OJEK",
    // Nature (Alam)
    "GUNUNG", "SUNGAI", "LAUT", "HUTAN", "PADANG", "DANAU", "PANTAI", "SAWAH",
    // Body parts (Anggota Tubuh)
    "KEPALA", "MATA", "HIDUNG", "MULUT", "TELINGA", "TANGAN", "KAKI", "RAMBUT",
  ],
  hard: [
    // Professions (Profesi)
    "DOKTER", "GURU", "POLISI", "PETANI", "PILOT", "INSINYUR", "HAKIM", "WARTAWAN",
    // Technology (Teknologi)
    "KOMPUTER", "INTERNET", "SMARTPHONE", "LAPTOP", "ROBOT", "SATELIT", "KAMERA", "PRINTER",
    // Education (Pendidikan)
    "SEKOLAH", "UNIVERSITAS", "PERPUSTAKAAN", "LABORATORIUM", "KELAS", "BUKU", "PENSIL", "PAPAN",
    // Foods (Makanan)
    "NASI", "RENDANG", "SATE", "GUDEG", "BAKSO", "SOTO", "GADO", "RUJAK",
  ]
};

export function getWordsForDifficulty(difficulty: "easy" | "medium" | "hard", count: number): string[] {
  const words = INDONESIAN_WORDS[difficulty];
  const shuffled = [...words].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

export function getGridSize(difficulty: "easy" | "medium" | "hard"): number {
  switch (difficulty) {
    case "easy": return 8;
    case "medium": return 10;
    case "hard": return 12;
    default: return 8;
  }
}

export function getWordCount(difficulty: "easy" | "medium" | "hard"): number {
  switch (difficulty) {
    case "easy": return 5;
    case "medium": return 8;
    case "hard": return 12;
    default: return 5;
  }
}
