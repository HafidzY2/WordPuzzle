import { GameCell, WordPosition, Difficulty } from "@shared/schema";
import { getWordsForDifficulty, getGridSize, getWordCount } from "./indonesianWords";

export type Direction = {
  dx: number;
  dy: number;
  name: "horizontal" | "vertical" | "diagonal";
};

const DIRECTIONS: Direction[] = [
  { dx: 0, dy: 1, name: "horizontal" }, // right
  { dx: 1, dy: 0, name: "vertical" }, // down
  { dx: 1, dy: 1, name: "diagonal" }, // down-right
  { dx: 1, dy: -1, name: "diagonal" }, // down-left
  { dx: 0, dy: -1, name: "horizontal" }, // left
  { dx: -1, dy: 0, name: "vertical" }, // up
  { dx: -1, dy: -1, name: "diagonal" }, // up-left
  { dx: -1, dy: 1, name: "diagonal" }, // up-right
];

export function generateGrid(difficulty: Difficulty): {
  grid: GameCell[][];
  words: WordPosition[];
} {
  const size = getGridSize(difficulty);
  const wordCount = getWordCount(difficulty);
  const words = getWordsForDifficulty(difficulty, wordCount);
  
  // Initialize empty grid
  const grid: GameCell[][] = Array(size).fill(null).map((_, row) =>
    Array(size).fill(null).map((_, col) => ({
      letter: "",
      row,
      col,
      isSelected: false,
      isFound: false,
    }))
  );

  const placedWords: WordPosition[] = [];

  // Place words in grid
  for (const word of words) {
    let placed = false;
    let attempts = 0;
    const maxAttempts = 100;

    while (!placed && attempts < maxAttempts) {
      const direction = DIRECTIONS[Math.floor(Math.random() * DIRECTIONS.length)];
      const startRow = Math.floor(Math.random() * size);
      const startCol = Math.floor(Math.random() * size);

      if (canPlaceWord(grid, word, startRow, startCol, direction, size)) {
        placeWord(grid, word, startRow, startCol, direction);
        
        const endRow = startRow + direction.dx * (word.length - 1);
        const endCol = startCol + direction.dy * (word.length - 1);
        
        placedWords.push({
          word,
          startRow,
          startCol,
          endRow,
          endCol,
          direction: direction.name,
          found: false,
        });
        
        placed = true;
      }
      attempts++;
    }
  }

  // Fill empty cells with random letters
  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (grid[row][col].letter === "") {
        grid[row][col].letter = letters[Math.floor(Math.random() * letters.length)];
      }
    }
  }

  return { grid, words: placedWords };
}

function canPlaceWord(
  grid: GameCell[][],
  word: string,
  startRow: number,
  startCol: number,
  direction: Direction,
  size: number
): boolean {
  const endRow = startRow + direction.dx * (word.length - 1);
  const endCol = startCol + direction.dy * (word.length - 1);

  // Check if word fits in grid
  if (endRow < 0 || endRow >= size || endCol < 0 || endCol >= size) {
    return false;
  }

  // Check if cells are empty or contain the same letter
  for (let i = 0; i < word.length; i++) {
    const row = startRow + direction.dx * i;
    const col = startCol + direction.dy * i;
    const cell = grid[row][col];
    
    if (cell.letter !== "" && cell.letter !== word[i]) {
      return false;
    }
  }

  return true;
}

function placeWord(
  grid: GameCell[][],
  word: string,
  startRow: number,
  startCol: number,
  direction: Direction
): void {
  for (let i = 0; i < word.length; i++) {
    const row = startRow + direction.dx * i;
    const col = startCol + direction.dy * i;
    grid[row][col].letter = word[i];
  }
}

export function isValidWordSelection(
  selectedCells: GameCell[],
  words: WordPosition[]
): string | null {
  if (selectedCells.length < 2) return null;

  const selectedWord = selectedCells.map(cell => cell.letter).join("");
  const reversedWord = selectedWord.split("").reverse().join("");

  for (const wordPos of words) {
    if (wordPos.found) continue;
    
    if (wordPos.word === selectedWord || wordPos.word === reversedWord) {
      // Check if selection matches word position
      if (isSelectionMatchingWord(selectedCells, wordPos)) {
        return wordPos.word;
      }
    }
  }

  return null;
}

function isSelectionMatchingWord(
  selectedCells: GameCell[],
  wordPos: WordPosition
): boolean {
  if (selectedCells.length !== wordPos.word.length) return false;

  // Get the direction of selection
  const first = selectedCells[0];
  const last = selectedCells[selectedCells.length - 1];
  
  // Check if selection matches word position (forward or backward)
  const matchesForward = 
    (first.row === wordPos.startRow && first.col === wordPos.startCol) ||
    (first.row === wordPos.endRow && first.col === wordPos.endCol);
    
  if (!matchesForward) return false;

  // Verify all cells are in correct positions
  const dx = wordPos.endRow - wordPos.startRow;
  const dy = wordPos.endCol - wordPos.startCol;
  const wordLength = wordPos.word.length;
  
  const stepX = dx === 0 ? 0 : dx / (wordLength - 1);
  const stepY = dy === 0 ? 0 : dy / (wordLength - 1);

  for (let i = 0; i < selectedCells.length; i++) {
    const expectedRow = wordPos.startRow + stepX * i;
    const expectedCol = wordPos.startCol + stepY * i;
    
    const cell = selectedCells[i];
    if (cell.row !== expectedRow || cell.col !== expectedCol) {
      // Try reverse direction
      const reverseExpectedRow = wordPos.endRow - stepX * i;
      const reverseExpectedCol = wordPos.endCol - stepY * i;
      
      if (cell.row !== reverseExpectedRow || cell.col !== reverseExpectedCol) {
        return false;
      }
    }
  }

  return true;
}

export function calculateScore(
  word: string,
  timeBonus: number,
  hintsUsed: number,
  difficulty: Difficulty
): number {
  const baseScore = word.length * 10;
  const difficultyMultiplier = difficulty === "easy" ? 1 : difficulty === "medium" ? 1.5 : 2;
  const hintPenalty = hintsUsed * 5;
  
  return Math.max(0, Math.round((baseScore * difficultyMultiplier + timeBonus) - hintPenalty));
}

export function getRandomHint(words: WordPosition[]): string | null {
  const unFoundWords = words.filter(w => !w.found);
  if (unFoundWords.length === 0) return null;
  
  const randomWord = unFoundWords[Math.floor(Math.random() * unFoundWords.length)];
  const hints = [
    `Cari kata "${randomWord.word}"`,
    `Kata ${randomWord.word.length} huruf: ${randomWord.word[0]}...${randomWord.word[randomWord.word.length - 1]}`,
    `Arah: ${randomWord.direction === "horizontal" ? "mendatar" : randomWord.direction === "vertical" ? "menurun" : "diagonal"}`,
  ];
  
  return hints[Math.floor(Math.random() * hints.length)];
}
