import { useState, useEffect } from "react";
import { Puzzle, Volume2, VolumeX, Settings, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useGameState } from "@/hooks/useGameState";
import { GameStats } from "@/components/GameStats";
import { WordSearchGrid } from "@/components/WordSearchGrid";
import { WordList } from "@/components/WordList";
import { DifficultySelector } from "@/components/DifficultySelector";
import { GameControls } from "@/components/GameControls";
import { GameCompleteModal } from "@/components/GameCompleteModal";
import { HelpModal } from "@/components/HelpModal";
import { Difficulty } from "@shared/schema";

export default function Game() {
  const [showHelp, setShowHelp] = useState(false);
  const [playerProgress, setPlayerProgress] = useState(null);
  const { toast } = useToast();
  
  const {
    gameState,
    selectedCells,
    isSelecting,
    soundEnabled,
    timer,
    startNewGame,
    pauseGame,
    resetGame,
    selectCell,
    extendSelection,
    finishSelection,
    useHint,
    toggleSound,
  } = useGameState();

  // Initialize game on first load
  useEffect(() => {
    if (!gameState) {
      startNewGame("easy");
    }
  }, [gameState, startNewGame]);

  const handleUseHint = () => {
    const hint = useHint();
    if (hint) {
      toast({
        title: "💡 Petunjuk",
        description: hint,
      });
    } else {
      toast({
        title: "Tidak ada petunjuk",
        description: "Semua kata sudah ditemukan!",
        variant: "destructive",
      });
    }
  };

  const handleShuffle = () => {
    if (gameState) {
      startNewGame(gameState.difficulty);
      toast({
        title: "Grid diacak",
        description: "Puzzle baru telah dibuat!",
      });
    }
  };

  const handleDifficultyChange = (difficulty: Difficulty) => {
    startNewGame(difficulty);
    toast({
      title: "Kesulitan diubah",
      description: `Game baru dimulai dengan tingkat ${difficulty}`,
    });
  };

  const handleNextLevel = () => {
    if (gameState) {
      const nextDifficulty = 
        gameState.difficulty === "easy" ? "medium" : 
        gameState.difficulty === "medium" ? "hard" : "hard";
      startNewGame(nextDifficulty);
    }
  };

  const formatTimeElapsed = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (!gameState) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Puzzle className="w-12 h-12 text-primary mx-auto mb-4" />
          <p className="text-gray-600">Memuat game...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Puzzle className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">Puzzle Kata</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Sound Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleSound}
                className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200"
              >
                {soundEnabled ? (
                  <Volume2 className="w-5 h-5 text-gray-600" />
                ) : (
                  <VolumeX className="w-5 h-5 text-gray-600" />
                )}
              </Button>
              
              {/* Help */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowHelp(true)}
                className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200"
              >
                <HelpCircle className="w-5 h-5 text-gray-600" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Game Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Game Board Section */}
          <div className="lg:col-span-3">
            {/* Game Stats Bar */}
            <GameStats gameState={gameState} timeRemaining={timer.formatTime()} />

            {/* Word Search Grid */}
            <WordSearchGrid
              gameState={gameState}
              onCellMouseDown={selectCell}
              onCellMouseEnter={extendSelection}
              onCellMouseUp={finishSelection}
              onUseHint={handleUseHint}
              onShuffle={handleShuffle}
            />
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* Word List */}
            <WordList words={gameState.words} />

            {/* Progress */}
            <div className="bg-white rounded-xl shadow-sm p-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Kemajuan</h3>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Level {gameState.level}</span>
                    <span>{Math.round((gameState.foundWords.length / gameState.words.length) * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(gameState.foundWords.length / gameState.words.length) * 100}%` }}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-gray-700">
                      {300 - timer.timeRemaining}s
                    </div>
                    <div className="text-xs text-gray-500">Waktu</div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-gray-700">{gameState.hintsUsed}</div>
                    <div className="text-xs text-gray-500">Hints</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Difficulty Selector */}
            <DifficultySelector
              currentDifficulty={gameState.difficulty}
              onDifficultyChange={handleDifficultyChange}
              disabled={gameState.isPlaying && !gameState.isPaused}
            />

            {/* Game Controls */}
            <GameControls
              isPlaying={gameState.isPlaying}
              isPaused={gameState.isPaused}
              onNewGame={() => startNewGame(gameState.difficulty)}
              onPauseGame={pauseGame}
              onResetGame={resetGame}
            />
          </div>
        </div>
      </main>

      {/* Game Complete Modal */}
      <GameCompleteModal
        isOpen={gameState.isComplete}
        onClose={() => {}}
        score={gameState.score}
        timeElapsed={formatTimeElapsed(300 - timer.timeRemaining)}
        wordsFound={gameState.foundWords.length}
        totalWords={gameState.words.length}
        onNextLevel={handleNextLevel}
        onPlayAgain={() => startNewGame(gameState.difficulty)}
      />

      {/* Help Modal */}
      <HelpModal
        isOpen={showHelp}
        onClose={() => setShowHelp(false)}
      />
    </div>
  );
}
