import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameStatsSchema, insertPlayerProgressSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get player progress
  app.get("/api/player/:playerId/progress", async (req, res) => {
    try {
      const { playerId } = req.params;
      const progress = await storage.getPlayerProgress(playerId);
      
      if (!progress) {
        // Create default progress for new player
        const defaultProgress = {
          playerId,
          currentLevel: 1,
          totalScore: 0,
          gamesPlayed: 0,
          bestScore: 0,
          difficulty: "easy" as const,
          soundEnabled: true,
        };
        
        const newProgress = await storage.createPlayerProgress(defaultProgress);
        return res.json(newProgress);
      }
      
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to get player progress" });
    }
  });

  // Update player progress
  app.patch("/api/player/:playerId/progress", async (req, res) => {
    try {
      const { playerId } = req.params;
      const updates = req.body;
      
      const progress = await storage.updatePlayerProgress(playerId, updates);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to update player progress" });
    }
  });

  // Create game stats
  app.post("/api/game-stats", async (req, res) => {
    try {
      const validatedData = insertGameStatsSchema.parse(req.body);
      const stats = await storage.createGameStats(validatedData);
      res.json(stats);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create game stats" });
    }
  });

  // Get game stats for player
  app.get("/api/player/:playerId/stats", async (req, res) => {
    try {
      const { playerId } = req.params;
      const stats = await storage.getGameStatsByPlayer(playerId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get game stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
