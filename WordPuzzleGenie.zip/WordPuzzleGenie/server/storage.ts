import { type GameStats, type InsertGameStats, type PlayerProgress, type InsertPlayerProgress } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Game Stats
  createGameStats(stats: InsertGameStats): Promise<GameStats>;
  getGameStatsByPlayer(playerId: string): Promise<GameStats[]>;
  
  // Player Progress
  getPlayerProgress(playerId: string): Promise<PlayerProgress | undefined>;
  createPlayerProgress(progress: InsertPlayerProgress): Promise<PlayerProgress>;
  updatePlayerProgress(playerId: string, progress: Partial<PlayerProgress>): Promise<PlayerProgress>;
}

export class MemStorage implements IStorage {
  private gameStats: Map<string, GameStats>;
  private playerProgress: Map<string, PlayerProgress>;

  constructor() {
    this.gameStats = new Map();
    this.playerProgress = new Map();
  }

  async createGameStats(insertStats: InsertGameStats): Promise<GameStats> {
    const id = randomUUID();
    const stats: GameStats = {
      ...insertStats,
      id,
      createdAt: new Date(),
    };
    this.gameStats.set(id, stats);
    return stats;
  }

  async getGameStatsByPlayer(playerId: string): Promise<GameStats[]> {
    return Array.from(this.gameStats.values()).filter(
      (stats) => stats.playerId === playerId
    );
  }

  async getPlayerProgress(playerId: string): Promise<PlayerProgress | undefined> {
    return this.playerProgress.get(playerId);
  }

  async createPlayerProgress(insertProgress: InsertPlayerProgress): Promise<PlayerProgress> {
    const id = randomUUID();
    const progress: PlayerProgress = {
      ...insertProgress,
      id,
      updatedAt: new Date(),
    };
    this.playerProgress.set(insertProgress.playerId, progress);
    return progress;
  }

  async updatePlayerProgress(playerId: string, updates: Partial<PlayerProgress>): Promise<PlayerProgress> {
    const existing = this.playerProgress.get(playerId);
    if (!existing) {
      throw new Error("Player progress not found");
    }
    
    const updated: PlayerProgress = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };
    
    this.playerProgress.set(playerId, updated);
    return updated;
  }
}

export const storage = new MemStorage();
