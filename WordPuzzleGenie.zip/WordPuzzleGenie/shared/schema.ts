import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const gameStats = pgTable("game_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull(),
  score: integer("score").notNull().default(0),
  level: integer("level").notNull().default(1),
  wordsFound: integer("words_found").notNull().default(0),
  totalWords: integer("total_words").notNull().default(0),
  timeElapsed: integer("time_elapsed").notNull().default(0),
  difficulty: varchar("difficulty").notNull().default("easy"),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const playerProgress = pgTable("player_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playerId: varchar("player_id").notNull().unique(),
  currentLevel: integer("current_level").notNull().default(1),
  totalScore: integer("total_score").notNull().default(0),
  gamesPlayed: integer("games_played").notNull().default(0),
  bestScore: integer("best_score").notNull().default(0),
  difficulty: varchar("difficulty").notNull().default("easy"),
  soundEnabled: boolean("sound_enabled").notNull().default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertGameStatsSchema = createInsertSchema(gameStats).omit({
  id: true,
  createdAt: true,
});

export const insertPlayerProgressSchema = createInsertSchema(playerProgress).omit({
  id: true,
  updatedAt: true,
});

export type InsertGameStats = z.infer<typeof insertGameStatsSchema>;
export type GameStats = typeof gameStats.$inferSelect;
export type InsertPlayerProgress = z.infer<typeof insertPlayerProgressSchema>;
export type PlayerProgress = typeof playerProgress.$inferSelect;

// Game types
export type Difficulty = "easy" | "medium" | "hard";

export type GameCell = {
  letter: string;
  row: number;
  col: number;
  isSelected: boolean;
  isFound: boolean;
  wordId?: string;
};

export type WordPosition = {
  word: string;
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
  direction: "horizontal" | "vertical" | "diagonal";
  found: boolean;
};

export type GameState = {
  grid: GameCell[][];
  words: WordPosition[];
  foundWords: string[];
  score: number;
  level: number;
  timeElapsed: number;
  isPlaying: boolean;
  isPaused: boolean;
  isComplete: boolean;
  difficulty: Difficulty;
  hintsUsed: number;
};
